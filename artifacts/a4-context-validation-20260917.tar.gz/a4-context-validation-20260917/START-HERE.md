# A4 跨机验证移交包

这是已准备的验证方案与输入材料；目标机器实测尚未执行。

1. 完整解压并保留目录结构。
2. 阅读 [移交入口](method/validation/a4-context/README.md)，再按 [正式方案](method/docs/superpowers/plans/2026-09-17-a4-context-validation.md)执行。
3. `method/` 是操作者材料目录；其中 README 提供可直接发送给执行 Agent 的续接提示。运行说明中的“方法根目录”指此目录。
4. `pilot-inputs/` 是从 explicit-architecture 复制的本轮只读输入。按 cases.md 建立每次独立实验工作区，保持输入快照不变。
5. 首先核对目标机 Claude 的真实请求与原版 Superpowers，再运行 H1。本包已有 H1 诊断器；B 的语义注入器按正式方案 Task 3 在目标机实现。

本包不含登录凭据、用户配置、原始会话日志或完整可构建项目。全 A4 的业务闭环仍需完整试点仓库。

`MANIFEST.json` 记录除自身外所有文件的 SHA256；`pilot-inputs/SNAPSHOT.json` 记录项目来源及输入文件哈希。旧文档中的原机绝对路径是历史证据索引，新的执行方案和移交材料使用相对路径。

快速检查诊断器（不启动 Claude）：

```sh
cd method
node --test validation/a4-context/h1/capture-hook.test.mjs
```
