# Files

- [System boundaries and data ownership](system-map.md) - Maps the bookstore services, their actual entrypoints and state owners, and the synchronous and asynchronous paths connecting them.
