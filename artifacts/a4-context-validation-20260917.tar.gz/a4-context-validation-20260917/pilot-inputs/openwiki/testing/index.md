# Files

- [Tests and verification boundaries](verification-map.md) - Routes changes to focused domain, handler, adapter, component, and live-system tests, identifying infrastructure requirements and what existing assertions do not prove.
