---
okf_version: "0.2"
---

# Files

- [Quickstart and task routing](quickstart.md) - Starts repository exploration with independent Java builds, focused tests, runtime prerequisites, and a task map across the bookstore and architecture workflow suite.

# Directories

- [architecture](architecture/)
- [concepts](concepts/)
- [integrations](integrations/)
- [operations](operations/)
- [testing](testing/)
- [workflows](workflows/)
