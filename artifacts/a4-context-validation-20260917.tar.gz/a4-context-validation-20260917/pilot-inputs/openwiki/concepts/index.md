# Files

- [Shared runtime primitives and extension seams](seedwork.md) - Explains seedwork bus dispatch, aggregate event publication, auto-configuration, and shared HTTP failure handling as consumed by the bookstore services.
